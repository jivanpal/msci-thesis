#!/bin/bash
watch -d -p -n0.1 sensors
