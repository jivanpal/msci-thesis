#!/bin/bash
watch -d -p -n 0.1 "./get-cpuinfo-freq.sh ; ./get-cpupower-info.sh"
