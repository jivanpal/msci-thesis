#!/bin/bash
grep cpu.*Hz /proc/cpuinfo
