#!/bin/sh

rm -f ._shatest_*
